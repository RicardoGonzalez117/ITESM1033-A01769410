#Ricardo Adolfo Gonzalez Terán
#ITESM Campus Toluca
#A01769410

En el modelo del problema del aeropuerto, genere clases para vuelos, pasajeros, pilotos, asistentes de vuelos, asi mismo, utilice agregaciones, composiciones y herencias. Por ultimo, destaque la nomenclatura sobre los eleementos que puede haber de cada clase´para tener una mejor vision del modelo, todo lo anterior esta digitalizado en un archivo .png y .csv para su revision